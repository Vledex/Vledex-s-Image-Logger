<br>
<div align="center">
    <img src="https://img.shields.io/github/languages/top/scoobyluvs/Fake-img-logger?color=%23000000">
    <img src="https://img.shields.io/github/stars/scoobyluvs/Fake-img-logger?color=%23000000&logoColor=%23000000">
    <br>
    <img src="https://img.shields.io/github/commit-activity/w/scoobyluvs/Fake-img-logger?color=%23000000"> 
    <img src="https://img.shields.io/github/last-commit/scoobyluvs/Fake-img-logger?color=%23000000&logoColor=%23000000">
</div>
<hr style="border-radius: 2%; margin-top: 60px; margin-bottom: 60px;" noshade="" size="20" width="100%">


<div align="center">
Before anything u NEED Python 3.9.5 

<a href="https://www.python.org/downloads/release/python-395/"> Download here </a>

**ADD TO PATH , IT WONT FUCKING WORK IF U DON'T ADD IT TO PATH**
</div>

## libs 

` pip install requests `

` pip install keyboard `

` pip install colorama `


## How to use



1.) Add your info into config.json

2.) Run main.py

3.) Image is built to the build folder (might change later on where it's sent via webhook)

5.) Now if u press `esc` key on your keyboard , it sends the emebed. `q` on the keyboard is to end the loop , and close the program 

If u want to make it send some info go into /assets and change the info there to just a string.


# Features 

<br>
<details>
    <summary>Highly Editable</summary>
    <ul>
        
        - Edit the webhooks name
        
        - Edit the bot's profile
        
        - Edit the programs name
        
        - Edit the creators name
        
        - Edit the emebed
        
        - Whats it sends
        
</details>
<br>

<br>
<details>
    <summary>Genrates Random Info</summary>
    <ul>
        
        - Roblox info :
            - Cookie
            - Robux (pending robux)
            - Password
            - Pin
            - Also grabs real info such as rap, freinds , followers , following...
        
        - Network :
            - IP
            - Region
            - Country 
            - Timezone
            ( it generates the region , country , timezone , base off the ip)
        
        - Discord :
            - Nirto (Day's left)
            - Billing
            - Token 
            - Email 
            - Phone
        
        - Password emebed
            - Browser's cookies
            - Brower's password
            - Broswer's wallet
            - Browser's history

   </details>
<br>




## preview

![text](https://cdn.discordapp.com/attachments/1048794610983501887/1058125870864289842/image.png)

## contact  

in dire need : t.me/s3xbands    
    
#### more stars = more features ( pc info gen , idk suggestions , wtv )
